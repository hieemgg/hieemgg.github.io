<?php


namespace WhichBrowser\Constants;

class Id
{
    const NONE = 0;
    const INFER = 1;
    const PATTERN = 2;
    const MATCH_UA = 4;
    const MATCH_PROF = 8;
}
