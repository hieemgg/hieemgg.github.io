<?php

namespace WhichBrowser\Data;

DeviceModels::$ASHA_INDEX = array (
  '@50' => 
  array (
    0 => 500,
    1 => 501,
    2 => '501s',
    3 => '501.1',
    4 => '501.2',
    5 => 502,
    6 => 503,
    7 => '503s',
  ),
  '@AS' => 
  array (
    0 => 'Asha230SingleSIM',
    1 => 'Asha230DualSIM',
    2 => 'Asha500SingleSIM',
    3 => 'Asha500DualSIM',
  ),
);
